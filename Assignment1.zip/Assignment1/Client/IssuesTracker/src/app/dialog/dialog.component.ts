import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  issueForm!: FormGroup;
  actionBtn : string = "Save";

  constructor(private formBuilder : FormBuilder,private api : ApiService,
    @Inject(MAT_DIALOG_DATA) public editData : any,
    private dialoRef : MatDialogRef<DialogComponent>) { }

  ngOnInit(): void {
    this.issueForm = this.formBuilder.group({
      id : ['',Validators.required],
      heading : ['',Validators.required],
      description: ['',Validators.required],
      assignedtoname : ['',Validators.required],
      reportername : ['',Validators.required]
    });

    if(this.editData){
      this.actionBtn = "Update";
      this.issueForm.controls['id'].setValue(this.editData.id);
      this.issueForm.controls['heading'].setValue(this.editData.heading);
      this.issueForm.controls['description'].setValue(this.editData.description);
      this.issueForm.controls['assignedtoname'].setValue(this.editData.assignedtoname);
      this.issueForm.controls['reportername'].setValue(this.editData.reportername);
    }
  }

  addStudent(){
    if(!this.editData){
      if(this.issueForm.valid)
    {
        this.api.postIssue(this.issueForm.value).subscribe({
          next:(res)=>{
            alert("Issue raised Successfully")
            this.issueForm.reset();
            this.dialoRef.close('save');
          },
          error:()=>{
            alert("Error while raising issue");
          }
        })
      }
    }
      else
    {
        this.updateIssue();
      }
    }
  

  updateIssue(){
    
    this.api.putIssue(this.issueForm.value,this.editData.id)
    .subscribe({
      next:(res)=>{
        alert("Issue updated successfully");
        this.issueForm.reset();
        this.dialoRef.close("Update");
      },
      error:()=>{
        alert("Error while updating the record");
      }
           
    })
  }

}
