import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http : HttpClient) {}
    postIssue(data : any){
      return this.http.post<any>("https://localhost:7250/issues/create/",data);
    }

    getIssues(){
      return this.http.get<any>("https://localhost:7250/issues");
    }
   

    putIssue(data: any , id : any){
      return this.http.put<any>("https://localhost:7250/edit/" + id, data);
    }

    deleteIssue(id : any){
      return this.http.delete<any>("https://localhost:7250/delete/" + id);

    }
}
