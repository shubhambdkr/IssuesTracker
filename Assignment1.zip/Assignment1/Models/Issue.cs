﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace IssuesTracker.Models
{
    public class Issue
    {
        [Key]
        [Required]
        public int Id { get; set; }
        [Required]
        public string Heading { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string AssignedToName { get; set; }
        [Required]
        public string ReporterName { get; set; }

    }
}
