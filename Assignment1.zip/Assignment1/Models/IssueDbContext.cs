﻿using Microsoft.EntityFrameworkCore;

namespace IssuesTracker.Models
{
    public class IssueDbContext : DbContext
    {
        public IssueDbContext(DbContextOptions<IssueDbContext> dbContextOptions)
            : base(dbContextOptions)
        {

        }

        public DbSet<Issue> IssuesTracker { set; get; }
    }
}
