﻿using IssuesTracker.Models;
using System.Data;
using System.Data.SqlClient;

namespace IssuesTracker.Repository
{
    public class IssueRepository : IIssue
    {
        public readonly IConfiguration _configuration;

        public IssueRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<List<Issue>> Get()
        {
            using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("ConnectionString")))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("spGetAllIssues", con);
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                List<Issue> issues = new List<Issue>();
                if(dt.Rows.Count>0)
                {
                    for(int i=0;i<dt.Rows.Count;i++)
                    {
                        Issue iss = new Issue();
                        iss.Id = Convert.ToInt32(dt.Rows[i]["Id"]);
                        iss.Heading = dt.Rows[i]["Heading"].ToString();
                        iss.Description = dt.Rows[i]["Description"].ToString();
                        iss.AssignedToName = dt.Rows[i]["AssignedToName"].ToString();
                        iss.ReporterName = dt.Rows[i]["ReporterName"].ToString();
                        issues.Add(iss);

                    }
                }
                return issues;

            }
        }
    }
}
