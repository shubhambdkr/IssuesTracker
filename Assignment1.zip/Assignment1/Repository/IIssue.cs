﻿using IssuesTracker.Models;
using Microsoft.AspNetCore.Mvc;

namespace IssuesTracker.Repository
{
    public interface IIssue
    {
        Task<List<Issue>> Get();
    }
}
